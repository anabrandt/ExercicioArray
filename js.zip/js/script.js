let taskForm = document.getElementById('task-form');
let taskList = document.getElementById('task-list');
let priorityList = document.getElementById('priority-list');
    let prioritySelect = document.getElementById('priority');
    let priorities = ['alta', 'média', 'baixa'];
  

    priorities.forEach(priority => {
        let option = document.createElement('option');
        option.value = priority;
        option.textContent = priority.charAt(0).toUpperCase() + priority.slice(1);
        prioritySelect.appendChild(option);
    });


taskForm.addEventListener('submit', function(event) {
    event.preventDefault();
    let taskInput = taskForm.querySelector('#task');
    let taskDescription = taskInput.value.trim();
    
    let listItem = document.createElement('li');
    listItem.innerHTML = `<input type="checkbox"><span>${taskDescription}</span><button class="delete-btn">Excluir</button>
    `;
    taskList.appendChild(listItem);
    taskInput.value = '';

    let deleteButton = listItem.querySelector('.delete-btn');
    deleteButton.addEventListener('click', function() {
        listItem.remove();
    });

    let checkbox = listItem.querySelector('input[type="checkbox"]');
    checkbox.addEventListener('change', function() {
        listItem.classList.toggle('completed', checkbox.checked);
    });

    let priorityItem = document.createElement('li');
            priorityItem.innerText = taskDescription;
            priorityList.appendChild(priorityItem);
});